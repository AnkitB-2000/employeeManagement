package com.employeeManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employeeManagement.service.LoginService;
import com.employeeManagement.entity.Login;


@RestController
@RequestMapping("/User")

public class LoginController {
	
			@Autowired
			LoginService loginService;
			
			static Login L=null;
			
			@PostMapping("/login")
			public  String getUser(@RequestParam("username") String username,
					@RequestParam("password") String password)
			{
				Login l=loginService.getUser(username);
				if(l.getPassword().equals(password)) {
					L=l;
					return "login successfully";
				}
				else
					return "wrong cread";
			}		
			
}
