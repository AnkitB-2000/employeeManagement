package com.employeeManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employeeManagement.entity.User;
import com.employeeManagement.repository.UserRepository;

@RestController
@RequestMapping("/api/v1")
public class LoginController {
    
    @Autowired
    private UserRepository userRepository;
    
    @GetMapping("/login")
    public String login() {
        return "login";
    }
    
    @SuppressWarnings("deprecation")
	@PostMapping("/login")
    public String authenticate(@RequestParam("username") String username, @RequestParam("password") String password) {
        // Authenticate the user by checking the username and password
        User user = userRepository.getById(username);
        if (user != null && user.getPassword().equals(password)) {
            return "Login Succesfull";
        } else {
            return "Wrong Credentials";
        }
    }
}
