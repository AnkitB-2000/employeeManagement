package com.employeeManagement.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeManagement.entity.Login;
import com.employeeManagement.repository.LoginRepository;
import com.employeeManagement.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginRepository loginRepo;
	@SuppressWarnings("deprecation")
	@Override
	public Login getUser(String S) {
		// TODO Auto-generated method stub
		return loginRepo.getById(S);
	}

}
