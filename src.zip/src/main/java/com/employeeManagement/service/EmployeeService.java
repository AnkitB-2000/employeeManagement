package com.employeeManagement.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.employeeManagement.entity.Employee;


public interface EmployeeService {

	List<Employee> getEmployees();

	Employee saveEmployees(Employee employee);

	Employee findEmployeeById(Long id);
	
	Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails);
	
	Employee deleteEmployee(@PathVariable Long id);
}
