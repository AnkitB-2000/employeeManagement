package com.employeeManagement.service;

import com.employeeManagement.entity.Login;

public interface LoginService {
	
	public Login getUser(String S);

}
