import React from 'react';
import { Navbar, Button } from 'react-bootstrap';
import logo from './logo.png'; 
import "./style.css";
import { useNavigate } from 'react-router-dom';

const navigate = useNavigate;

function handleClick(){
  navigate('http://localhost:3000/');
}

function CustomNavbar() {

  

  return (
    <div>
    <Navbar  expand="lg" style={{padding:"1%" ,background:"#455d7a "}}>
      <Navbar.Brand href="#home"><img src={logo} style={{width:"45px"}} ></img><b style={{color:"white"}}>Employeee Management System</b></Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
       <Button variant="primary"  style={{position:"absolute", right: 10}} type='submit' onSubmit={handleClick}>Log Out</Button>
      </Navbar.Collapse>
    </Navbar>
    </div>

   
  );
}

export default CustomNavbar;
