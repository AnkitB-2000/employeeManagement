import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {Container ,Card, Button} from 'react-bootstrap';  
import "./style.css";
import CustomNavbar from "./CustomNavbar";
import { useNavigate } from 'react-router-dom';


const CardView=()=> {
  const [data, setData] = useState([]);
  const navigate = useNavigate();
  function requestHandlerGenerateTax(amount,id){
    document.getElementById(id).innerHTML=amount*0.35+" Need to pay yearly";
  }
  const requestHandlerDelete = (id) => {

      const handleDelete = () => {
        {
          axios

            .delete("http://localhost:8083/api/v1/employees/"+id)
            .then((res) => {
              console.log(res.data);
            });

        }

      };
      handleDelete();
      alert("Employee deleted");
      // navigate('/CardView');
      window.location.reload();
    }
  const requestHandlerUpdate = (id,firstName,lastName,emailId,department,salary) =>{

   navigate('/updateComponent', { state: { Id: id, FirstName:firstName,LastName:lastName,EmailId:emailId,Department:department,Salary:salary} });
  
  }
  
  useEffect(() => {
    axios.get('http://localhost:8083/api/v1/employees')
      .then(response => {
        // Handle the response
        setData(response.data);
      })
      .catch(error => {
        // Handle the error
        console.error(error);
      });
  }, []);

  return (
    
    <div>
      <div style={{position:"fixed",zIndex:"1",width:"100%"}}>
    <CustomNavbar/>
    </div>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    {data.map(item => {
      const { id, firstName, lastName,emailId,department,salary} = item; // Store properties into variables
      return (
        <div>
          
           
  <Container >  
  <Card className="m-2"> 
  
  <Card.Body>  
    <table>
      <tr style={{display:'table-row'}}>
        <td style={{display:'table-cell', padding:10}}>{id}</td>
        <td style={{display:'table-cell', padding:10}}>{firstName}</td>
        <td style={{display:'table-cell', padding:10}}>{lastName}</td>
        <td style={{display:'table-cell', padding:10}}>{emailId}</td>
        <td style={{display:'table-cell', padding:10}}>{department}</td>
        <td style={{display:'table-cell', padding:10}}>{salary}</td>
        <td style={{display:'table-cell',padding:10}}><Button  variant="primary" onClick = {()=>requestHandlerUpdate(id,firstName,lastName,emailId,department,salary)}>Update</Button></td>
        <td style={{display:'table-cell',padding:10}}><Button onClick={()=>requestHandlerDelete(id)} variant="danger">Delete</Button></td>
        <td style={{display:'table-cell', padding:10}}><Button onClick={()=>requestHandlerGenerateTax(salary,id)} variant="primary"><h5 id={id}>Generate Tax</h5></Button></td>
        <td></td>
      </tr>
    </table>      
      
  </Card.Body>  
</Card>  
</Container>  

        </div>
      );
    })}
  </div>
  );
}

export default CardView;
