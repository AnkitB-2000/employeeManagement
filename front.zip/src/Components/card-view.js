import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {Container ,Card, Button} from 'react-bootstrap';  
import "./style.css";
import CustomNavbar from "./CustomNavbar"

const CardView=()=> {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8083/api/v1/employees')
      .then(response => {
        // Handle the response
        setData(response.data);
      })
      .catch(error => {
        // Handle the error
        console.error(error);
      });
  }, []);

  return (
    
    <div>
      <div style={{position:"fixed",zIndex:"1",width:"100%"}}>
    <CustomNavbar/>
    </div>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    {data.map(item => {
      const { id, firstName, lastName,department,emailId,salary} = item; // Store properties into variables
      return (
        <div>
          
           
  <Container >  
  <Card className="m-2"> 
  
  <Card.Body>  
    <table>
      <tr style={{display:'table-row'}}>
        <td style={{display:'table-cell', padding:10}}>{id}</td>
        <td style={{display:'table-cell', padding:10}}>{firstName}</td>
        <td style={{display:'table-cell', padding:10}}>{lastName}</td>
        <td style={{display:'table-cell', padding:10}}>{department}</td>
        <td style={{display:'table-cell', padding:10}}>{emailId}</td>
        <td style={{display:'table-cell', padding:10}}>{salary}</td>
        <td style={{display:'table-cell', padding:10}}><Button variant="primary">Generate Tax</Button></td>
      </tr>
    </table>      
      
  </Card.Body>  
</Card>  
</Container>  

        </div>
      );
    })}
  </div>
  );
}

export default CardView;
