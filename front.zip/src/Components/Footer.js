import React from 'react';
import "./style.css";
function Footer() {
  return (
    <div className='footer' style={{background:"black"}}>
    <p style={{color:"white"}}>"Experience the allure of seamless booking and irresistible deals on our visually stunning selling website."</p>
    </div>
  );
}

export default Footer;
