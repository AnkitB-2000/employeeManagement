import React from 'react';
import "./style.css";
function Footer() {
  return (
    <div className='footer' style={{background:"black"}}>
    <p style={{color:"white"}}></p>
    </div>
  );
}

export default Footer;
