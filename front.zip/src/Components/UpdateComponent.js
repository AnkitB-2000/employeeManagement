import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import axios from 'axios';
import  "./style.css";
import Button from "react-bootstrap/Button";
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';

const UpdateForm = () => {
    const navigate = useNavigate();
    const {state} = useLocation();
    const { Id,FirstName,LastName,EmailId,Department,Salary} = state; 
    const [ id ] = useState(Id);
    const [firstName, setFirstName] = useState(FirstName);
    const [lastName, setLastName] = useState(LastName);
    const [emailId,setEmailId]=useState(EmailId);
    const [department,setDepartment]=useState(Department);
    const [salary,setSalary]=useState(Salary);
    

    function handleClick(event) {
        navigate('/CardView');
       }
       

  
    
    const handleSubmit = async (e) => {
        e.preventDefault();
      
        try {
          const response = await axios.put(`http://localhost:8083/api/v1/employees/${id}`,{id, firstName,lastName,emailId,department,salary});
          console.log(response.data); // Assuming the server returns a response message
          // Handle successful login
          handleClick();
        } catch (error) {
            console.log(error);
          console.error(error); // Handle error
        }
      };
  
    return (
      <div className='LoginForm'>
      <h1><b>Update Form</b></h1>
      
      <form onSubmit={handleSubmit}>
        
        <input
          type="text"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
          placeholder="First Name"
          style={{margin:"20px"}}
        />
        <input
          type="text"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
          placeholder="Last Name"
          style={{margin:"20px"}}
        />
        <br></br>
         <input
          type="text"
          value={emailId}
          onChange={(e) => setEmailId(e.target.value)}
          placeholder="email"
          style={{margin:"20px"}}
        />
        <input
          type="text"
          value={department}
          onChange={(e) => setDepartment(e.target.value)}
          placeholder="department"
          style={{margin:"20px"}}
        />
        <br></br>
        <input
          type="number"
          value={salary}
          onChange={(e) => setSalary(e.target.value)}
          placeholder="salary"
          style={{margin:"20px"}}
        />
      
        <br></br>
        
        
        <br></br>
        <Button variant='dark' onSubmit={handleSubmit} type="submit" ><b>Update</b></Button>
      </form>
      <br></br>      
       </div> );
  };
  
  export default UpdateForm;