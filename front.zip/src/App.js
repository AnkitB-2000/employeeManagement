import logo from './logo.svg';
import LoginForm from "./Components/login-form"
import './App.css';
import RegisterForm from './Components/register-form';
import CardView from './Components/card-view';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Footer from "./Components/Footer";
import UpdateComponent from "./Components/UpdateComponent";
import { GlobalProvider } from './context/global';

function App() {
  return (
    <GlobalProvider>
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path="Login" element={<LoginForm />} />
        <Route path='RegisterForm' element={<RegisterForm/>}/>
        <Route path="CardView" element={<CardView/>} />
        <Route path="UpdateComponent" element={<UpdateComponent/>} />

      </Routes>
      </BrowserRouter>
      <Footer/>
    </div>
    </GlobalProvider>
  );
}

export default App;
