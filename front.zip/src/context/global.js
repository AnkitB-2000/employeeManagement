import React, { createContext, useReducer } from 'react';
import AppReducer from './AppReducer';

// Initial state
const initialState = {
  loggedIn: false
}

// Create context
export const GlobalContext = createContext(initialState);

// Provider component
export const GlobalProvider = ({ children }) => {
  const [state, dispatch] = useReducer(AppReducer, initialState);

  // Actions
  function logUserOut() {
    dispatch({
      type: 'LOG_OUT',
    //   payload: id
    });
  }

  function logUserIn() {
    dispatch({
      type: 'LOG_IN'
    });
  }

  return (<GlobalContext.Provider value={{
    loggedIn: state.loggedIn,
    logUserOut,
    logUserIn
  }}>
    {children}
  </GlobalContext.Provider>);
}