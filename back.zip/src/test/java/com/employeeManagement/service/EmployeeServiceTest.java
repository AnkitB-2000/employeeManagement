package com.employeeManagement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Optional;


import org.junit.jupiter.api.Test;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;



import com.employeeManagement.entity.Employee;
import com.employeeManagement.repository.EmployeeRepository;

@SpringBootTest
public class EmployeeServiceTest {
	
	@Autowired
	private EmployeeService employeeService;
	
	@MockBean
	private EmployeeRepository employeeRepository;
	

	
	@Test
	public void testFindEmployeeById() {
		
		Employee employee = new Employee(1L,"abc","def","abc@gmail.com","HR",20000);
		when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

		String employeeName="abc";
		Employee employeeById = employeeService.findEmployeeById(1L);
		assertEquals(employeeName,employeeById.getFirstName());
	}
	@Test
    void testSaveEmployees() {
        
        Employee mockEmployee = new Employee();
        mockEmployee.setFirstName("John");
        mockEmployee.setLastName("Cena");

       
        when(employeeRepository.save(mockEmployee)).thenReturn(mockEmployee);

        
        Employee result = employeeService.saveEmployees(mockEmployee);

        assertEquals(mockEmployee, result);
        verify(employeeRepository).save(mockEmployee);
    }
	@Test
    public void testUpdateEmployee() {
     

       
        Long id = 1L;
        Employee existingEmployee = new Employee();
        Employee updatedEmployeeDetails = new Employee( );

        
        when(employeeRepository.findById(id)).thenReturn(Optional.of(existingEmployee));
        when(employeeRepository.save(existingEmployee)).thenReturn(existingEmployee);

        Employee updatedEmployee = employeeService.updateEmployee(id, updatedEmployeeDetails);

        
        verify(employeeRepository, times(1)).findById(id);
        verify(employeeRepository, times(1)).save(existingEmployee);
        verifyNoMoreInteractions(employeeRepository);

       
        assertEquals(updatedEmployeeDetails.getFirstName(), updatedEmployee.getFirstName());
        assertEquals(updatedEmployeeDetails.getLastName(), updatedEmployee.getLastName());
        assertEquals(updatedEmployeeDetails.getEmailId(), updatedEmployee.getEmailId());
        assertEquals(updatedEmployeeDetails.getDepartment(), updatedEmployee.getDepartment());
        assertEquals(updatedEmployeeDetails.getSalary(), updatedEmployee.getSalary());
    }
	 @Test
	    void testDeleteEmployee() {
	        
	        Employee mockEmployee = new Employee(1L,"","","","",12000);
	        
	        mockEmployee.setFirstName("John");
	        when(employeeRepository.findById(1L)).thenReturn(Optional.of(mockEmployee));
	        
	        Employee result = employeeService.deleteEmployee(1L);

	        assertEquals(mockEmployee, result);
	        verify(employeeRepository).delete(mockEmployee);
	    }
	
	
}
