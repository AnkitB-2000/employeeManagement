package com.employeeManagement.controller;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.http.MediaType;

import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.employeeManagement.entity.Employee;
import com.employeeManagement.service.EmployeeService;

@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmployeeService employeeService;

	private Employee employee;

	@Test
	public void testCreateEmployee() throws Exception {

		Mockito.when(employeeService.saveEmployees(employee)).thenReturn(employee);
		mockMvc.perform(
				MockMvcRequestBuilders.post("/api/v1/employees").contentType(MediaType.APPLICATION_JSON).content(
						"{\"id\":1,\"firstName\":\"abc\",\"lastName\":\"def\",\"emailId\":\"abcd@gmail.com\",\"department\":\"HR\",\"salary\":12000}"))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}
}
