package com.employeeManagement.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.employeeManagement.entity.Employee;
import com.employeeManagement.repository.EmployeeRepository;
import com.employeeManagement.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee saveEmployees(Employee employee) {
		
		return employeeRepository.save(employee);
	}

	

	@Override
	public Employee findEmployeeById(Long id) {
		
		Employee employee = employeeRepository.findById(id).get();
				
		return employee;
	}

	@Override
	public Employee updateEmployee(Long id, Employee employeeDetails) {
		
		Employee employee = employeeRepository.findById(id)
				.get();
		
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastName(employeeDetails.getLastName());
		employee.setEmailId(employeeDetails.getEmailId());
		employee.setDepartment(employeeDetails.getDepartment());
		employee.setSalary(employeeDetails.getSalary());
		
		Employee updatedEmployee = employeeRepository.save(employee);
		return updatedEmployee;
	}

	@Override
	public Employee deleteEmployee(Long id) {
		Employee employee = employeeRepository.findById(id).get();
				
		
		employeeRepository.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return employee;
	}

}
