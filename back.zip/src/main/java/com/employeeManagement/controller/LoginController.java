package com.employeeManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employeeManagement.entity.User;
import com.employeeManagement.repository.UserRepository;


@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/api/v1")
public class LoginController {

	
	@Autowired
    private UserRepository userRepository;
	
	
	@PostMapping("/login")
	public String authenticate(@RequestParam("username") String username, @RequestParam("password") String password) {
		 
		@SuppressWarnings("deprecation")
		User user = userRepository.getById(username);
		if (user != null && user.getPassword().equals(password) && user.getUsername().equals(username)) {
			return "Login Successfull";
		} else {
			return "Wrong Credentials";
		}
		
	}
}
