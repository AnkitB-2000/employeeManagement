import React from 'react';
import { Navbar, Button } from 'react-bootstrap';
import logo from './logo.png'; 
import "./style.css";
import { useNavigate } from 'react-router-dom';
import { GlobalContext } from '../context/global';
import { useContext } from 'react';


function CustomNavbar() {
  
  const navigate = useNavigate();
  const { logUserOut } = useContext(GlobalContext);
  function handleClick2(event){
  navigate('/RegisterForm');
}
function handleClick(event){
  logUserOut();
  navigate('/');
}

  return (
    <div>
    <Navbar  expand="lg" style={{padding:"1%" ,background:"#455d7a "}}>
      <Navbar.Brand href="#home"><img src={logo} style={{width:"45px"}} ></img><b style={{color:"white"}}>Employeee Management System</b></Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Button variant="dark" onClick={handleClick2} style={{position:"absolute", right: 100}} type='submit'> Add Employees</Button>
       <Button variant="primary" onClick={handleClick} style={{position:"absolute", right: 10}} type='submit' > Log Out</Button>
      </Navbar.Collapse>
    </Navbar>
    </div>

   
  );
}

export default CustomNavbar;
