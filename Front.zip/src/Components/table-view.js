import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {Table, Button} from 'react-bootstrap';  
import "./style.css";
import CustomNavbar from "./CustomNavbar";
import { Navigate, useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { GlobalContext } from '../context/global';


const TableView=()=> {
  const [data, setData] = useState([]);
  const { loggedIn } = useContext(GlobalContext);

  const navigate = useNavigate();

  console.log(loggedIn);
  function requestHandlerGenerateTax(amount,id){
    document.getElementById(id).innerHTML=(amount*0.35).toFixed(2);
  }
  const requestHandlerDelete = (id,firstName,lastName,emailId,department,salary) => {

      const handleDelete = () => {
        {
          axios

            .delete("http://localhost:8083/api/v1/employees/"+id)
            .then((res) => {
              navigate('/TableView',{ state: { Id: id, FirstName:firstName,LastName:lastName,EmailId:emailId,Department:department,Salary:salary} });
             
            });

        }

      };
      handleDelete();
      alert("Employee deleted");
      
    }
  const requestHandlerUpdate = (id,firstName,lastName,emailId,department,salary) =>{

   navigate('/UpdateComponent', { state: { Id: id, FirstName:firstName,LastName:lastName,EmailId:emailId,Department:department,Salary:salary} });
  
  }
  
  useEffect(() => {
    axios.get('http://localhost:8083/api/v1/employees')
      .then(response => {
        // Handle the response
        setData(response.data);
      })
      .catch(error => {
        // Handle the error
        console.error(error);
      });
  }, [data]);
  if(!loggedIn){
    return <Navigate to="/Login" />
  }
  return (
    
    <div>
      <div style={{position:"fixed",zIndex:"1",width:"100%"}}>
    <CustomNavbar/>
    </div>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    {data.map(item => {
      const { id, firstName, lastName,emailId,department,salary} = item; // Store properties into variables
      return (
        <div>
          
           
  <div className='row' >  
  
  <table class="table">
  <thead>
    <tr>
      <th scope="col" style={{paddingLeft : 50}}>ID</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email Id</th>
      <th scope="col">Department</th>
      <th scope="col">Salary</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">{id}</th>
      <td>{firstName}</td>
      <td>{lastName}</td>
      <td>{emailId}</td>
      <td>{department}</td>
      <td>{salary}</td>
      <td style={{display:'table-cell',padding:10}}><Button  variant="primary" onClick = {()=>requestHandlerUpdate(id,firstName,lastName,emailId,department,salary)}>Update</Button></td>
      <td style={{display:'table-cell',padding:10}}><Button onClick={()=>requestHandlerDelete(id)} variant="danger">Delete</Button></td>
      <td style={{display:'table-cell', padding:10}}><Button onClick={()=>requestHandlerGenerateTax(salary,id)} variant="primary"><h5 id={id}>Generate Tax</h5></Button></td>
    </tr>
  </tbody>
</table>
  
  
         
      
   
 
</div>  

        </div>
      );
    })}
  </div>
  );
}

export default TableView;
