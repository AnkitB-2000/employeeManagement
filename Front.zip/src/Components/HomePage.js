import { useNavigate } from 'react-router-dom';
import { Navbar,Button } from 'react-bootstrap';
import React from 'react';
import logo from './logo.png'



const HomePage=()=>{
    const navigate = useNavigate();
function handleClick(event){
    
    navigate('/Login');
}
    
return(
<div>
<Navbar  expand="lg" style={{padding:"1%" ,background:"black"}}>
      <Navbar.Brand href="#home"><img src={logo} style={{width:"45px"}} ></img><b style={{color:"white"}}>Employeee Management System</b></Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        
       <Button variant="primary" style={{position:"absolute", right:50}} onClick={handleClick} type='submit' > Log In</Button> 
      </Navbar.Collapse>
    </Navbar>
    
    <div className='Conatiner'>
       <p style={{color:"white",fontFamily:"sans-serif"}}> <h1>Welcome to Employee Management System</h1> </p>
    </div>
    <div style={{color:'white',fontFamily:'sans-serif',textAlign:'left',padding:10}}>
        <p>This is an employee management web application . This is an admin side application which can be used to store employee details like name , email address , department and salary.There is also a generate tax function which predicts the tax depending upon the annual salary . Admin can also update the employee details if required. Admin can delete the employee details if necessary. This web application is developed using Springboot , ReactJs and MySqL . </p>
   </div>
    <div>
   <ul style={{color:"white",padding:10,textAlign:'left'}}>
    <li>You can ADD employees by using the employee details like first name , last name , email address , department and salary</li>
    <li >You can UPDATE any field if you want</li>
    <li>You can DELETE any employee </li>
    <li>You can generate the tax </li>
   </ul>
    </div>
    
    <div style={{position:'absolute',paddingTop:100,left:30,color:"white"}}>
        <p>Please Login to Use</p>  
           
    <Button variant="primary" onClick={handleClick} type='submit' > Log In</Button> 

    </div>
</div>);
}
export {HomePage};