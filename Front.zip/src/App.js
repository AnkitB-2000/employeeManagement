
import LoginForm from "./Components/login-form"
import './App.css';
import RegisterForm from './Components/register-form';
import TableView from './Components/table-view';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Footer from "./Components/Footer";
import UpdateComponent from "./Components/UpdateComponent";
import { GlobalProvider } from './context/global';
import {HomePage} from "./Components/HomePage";

function App() {
  return (
    <GlobalProvider>
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage/>}/>
        <Route path="Login" element={<LoginForm />} />
        <Route path='RegisterForm' element={<RegisterForm/>}/>
        <Route path="TableView" element={<TableView/>} />
        <Route path="UpdateComponent" element={<UpdateComponent/>} />

      </Routes>
      </BrowserRouter>
      <Footer/>
    </div>
    </GlobalProvider>
  );
}

export default App;
