import logo from './logo.svg';
import './App.css';
import ListEmployeeComponent from './components/ListEmployeeComponent';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import {BrowserRouter}  from 'react-router-dom';
import {Routes, Route} from 'react-router'; 
import CreateEmployeeComponent from './components/CreateEmployeeComponent';

function App() {
  return(
  <div >

   
    <BrowserRouter>
    <HeaderComponent />
    <Routes>    
      <Route path='/' element={<ListEmployeeComponent/>}/>
      <Route path='/employees' element={<ListEmployeeComponent/>}/>
      <Route path='/add-employee' element={<CreateEmployeeComponent/>}/>
          </Routes>
    <FooterComponent />
    </BrowserRouter>
    </div>
  );
}

export default App;
